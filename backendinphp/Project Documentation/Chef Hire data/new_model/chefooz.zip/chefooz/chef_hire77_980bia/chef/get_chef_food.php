      <?php
mysql_connect("localhost", "chef_hire", "santoshpro95") or die("Connection Failed");
mysql_select_db("chef_hire")or die("Connection Failed");

/*get data from database*/
$chef_id=$_POST['chef_id'];

  $sql = "SELECT * from chef_food where chef_id= '$chef_id' ";

        $result = mysql_query($sql);
/*check data should be more than one*/
    
          if (mysql_num_rows($result) > 0) {
         while ($row = mysql_fetch_array($result)) {

           $postArray = array(

                 "food_name" => $row['food_name'],
      "food_price" =>  $row['food_price'],
      "food_info" => $row['food_info'],
	"success" => "true"
                );

             }

      $output = json_encode($postArray);
              echo $output;
      }else{
           $postArray = array(

                "success" => "false"

                );

             }

      $output = json_encode($postArray);
              echo $output;
      
      
     

?>
