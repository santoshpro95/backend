      <?php
mysql_connect("localhost", "chef_hire", "santoshpro95") or die("Connection Failed");
mysql_select_db("chef_hire")or die("Connection Failed");

/*get data from database*/
$user_phone=$_POST['user_phone'];
$sql = "select * from chef c, chef_food f where c.chef_id = f.chef_id and c.phone != '$user_phone'";
        $result = mysql_query($sql);
/*check data should be more than one*/
    
          if (mysql_num_rows($result) > 0) {
         while ($row = mysql_fetch_array($result)) {

           $postArray[] = array(

                  "name" =>  $row['name'],
                  "phone" =>  $row['phone'],
                   "address" =>  $row['address'],
                    "rating" =>  $row['rating'],
                  "image" =>  $row['image'],
                  "email" => $row['email'],
                   "status" => $row['status'],
                    "chef_id" => $row['chef_id'],
                     "lat" => $row['lat'],
                       "log" => $row['log'],
                         "type" => $row['type'],
                         "food_name" => $row['food_name'],
                          "food_info" => $row['food_info'],
                          "food_price" => $row['food_price']
                );

             }

      $output = json_encode(array('data' => $postArray));
              echo $output;
      }

?>
