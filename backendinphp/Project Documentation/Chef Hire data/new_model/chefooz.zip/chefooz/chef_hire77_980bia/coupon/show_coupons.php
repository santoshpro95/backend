      <?php
mysql_connect("localhost", "chef_hire", "santoshpro95") or die("Connection Failed");
mysql_select_db("chef_hire")or die("Connection Failed");

/*get data from database*/

$phone=$_POST['phone'];

  $sql = "SELECT * from user_coupons where phone = '$phone' ";

        
        $result = mysql_query($sql);
/*check data should be more than one*/
    
          if (mysql_num_rows($result) > 0) {
         while ($row = mysql_fetch_array($result)) {
         
          $postArray[] = array(

          	  "name" =>  $row['name'],
          	   "price" =>  $row['price'],
                  "coupon_id" =>  $row['coupon_id'],
                  "exp_date" =>  $row['exp_date'],
                  "status" =>  $row['status'],
                  "phone" =>  $row['phone'],
                  "price" =>  $row['discount'],
                  "title" =>  $row['title'],
                    "image" =>  $row['image'],
                   "desc" =>  $row['description']
                 );
         
         }
         
      $output = json_encode(array('data' => $postArray));
              echo $output;
      }
  

?>
