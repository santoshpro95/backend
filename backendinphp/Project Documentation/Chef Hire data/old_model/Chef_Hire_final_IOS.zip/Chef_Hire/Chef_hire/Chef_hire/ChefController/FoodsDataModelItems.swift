//
//  FoodsDataModelItems.swift
//  Chef_hire
//
//  Created by Reelover reelover on 10/08/18.
//  Copyright © 2018 Reelover. All rights reserved.
//

import Foundation
class FoodsDataModelItems {
    var switch_data: Bool?

}
