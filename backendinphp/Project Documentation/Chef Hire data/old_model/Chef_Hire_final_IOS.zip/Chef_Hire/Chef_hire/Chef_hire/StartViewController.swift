//
//  StartViewController.swift
//  Chef_hire
//
//  Created by Reelover reelover on 05/08/18.
//  Copyright © 2018 Reelover. All rights reserved.
//

import UIKit
import MapKit

class StartViewController: UIViewController {
    
    var logout:String = ""
    
    @IBOutlet weak var chewfController: UIButton!
    
    @IBOutlet weak var userController: UIButton!
    
    
    var locManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        locManager.requestWhenInUseAuthorization()

    }
      
}       // Do any additional setup after loading the view.

