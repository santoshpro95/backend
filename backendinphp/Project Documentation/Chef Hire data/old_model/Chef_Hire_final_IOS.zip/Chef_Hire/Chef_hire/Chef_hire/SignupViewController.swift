//
//  SignupViewController.swift
//  Chef_hire
//
//  Created by Reelover reelover on 03/08/18.
//  Copyright © 2018 Reelover. All rights reserved.
//

import UIKit
import Alamofire
import SVProgressHUD
import MapKit

class SignupViewController: UIViewController {

    var locManager = CLLocationManager()
    var currentLocation: CLLocation!
    var latitude = ""
    var longitude = ""
    
    @IBOutlet weak var phone_no: UILabel!
    @IBOutlet weak var fullName: UITextField!
    @IBOutlet weak var address: UITextField!
    @IBOutlet weak var submit: UIButton!
    
    var get_phoneNo : String = ""
  
//  getting api value
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        phone_no.text = "+91 \(get_phoneNo)"
        makeroundbtn()
        
        
        if (CLLocationManager.authorizationStatus() == CLAuthorizationStatus.authorizedWhenInUse){
            currentLocation = locManager.location
            
            print(currentLocation.coordinate.latitude)
            latitude = String(currentLocation.coordinate.latitude)
            
            print(currentLocation.coordinate.longitude)
            longitude = String(currentLocation.coordinate.longitude)
        }
        else{
            print("no user location")
        }
        
        // Do any additional setup after loading the view.
    }

    @IBAction func SubmitSignup(_ sender: Any) {

       let fullname : String = fullName.text!
       let full_address : String = address.text!
       
        
        save_data(Phone: get_phoneNo, name: fullname, address: full_address, latitude: latitude, longitude: longitude)
        
    }
    
    
    
    
    func save_data(Phone: String, name: String, address: String,latitude:String, longitude:String )  {
        
        SVProgressHUD.show()

        print("save data api calls : ");
        
        let parameters : Parameters = [
           "name" :name,
           "phone": Phone,
           "address" : address,
           "lat": latitude,
           "log": longitude
        ]
        
        let urlString = "http://www.zeenarch.com/chef_hire/new_user.php"

        Alamofire.request(urlString, method: .post, parameters: parameters, encoding:  URLEncoding.httpBody).responseJSON{ response in

            switch response.result {
                case .success:
                    debugPrint(response)

                    SVProgressHUD.dismiss()
                    
                    if let JSON = response.result.value{
                        
                        
                        var jsonobject = JSON as! [String: AnyObject]
                        
                        let name = (jsonobject["name"] as? String) ?? " "
                          let phone = (jsonobject["phone"] as? String) ?? " "
                          let address = (jsonobject["address"] as? String) ?? " "
                        
                        
                        
                        let userdefault = UserDefaults.standard
                
            
                       
                        
                        userdefault.set(name, forKey: "name")
                        userdefault.set(phone, forKey: "phone")
                        userdefault.set(address, forKey: "address")
                        userdefault.synchronize()
                    }
                    
                
                
                
                case .failure(let error):
                    print(error)
            }
        
         
        }
      
        
    }

    
    @IBAction func close(_ sender: Any) {
         self.dismiss(animated: true, completion: nil)
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>,
                               with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func makeroundbtn(){
        
        submit.layer.cornerRadius = 5
        submit.clipsToBounds = true
    }
 
}
