<?php




$servername = "localhost";
$username = "chef_hire";
$password = "santoshpro95";
$database ="chef_hire";
// Create connection
$conn = mysqli_connect($servername, $username,  $password, $database);
// Check connection


if ($conn->connect_error) {

    die("Connection failed: " . $conn->connect_error);
} 


$name=$_POST['name'];
$breakfast=  $_POST['breakfast'];
$lunch=  $_POST['lunch'];
$dinner=$_POST['dinner'];

$info=$_POST['info'];
$address=$_POST['address'];
$distance=$_POST['distance'];
$phone= $_POST['phone'];

$lat=$_POST['lat'];
$log=$_POST['log'];
$s_id = $_POST['s_id'];

$mon=$_POST['mon'];
$tue=$_POST['tue'];
$wed=$_POST['wed'];
$thu= $_POST['thu'];

$fri=$_POST['fri'];
$sat=$_POST['sat'];
$sun= $_POST['sun'];


$result = mysqli_query($conn,"SELECT * FROM services where phone = '$phone'");
 $rowco  = mysqli_num_rows($result);
//echo $rowco ;


if($rowco > 0){	


		$postArray = array(
		  
		      "user" =>"old"
		   
		    );

		 echo json_encode( $postArray );

}
else{

	$sql = "INSERT INTO services VALUES (NULL,'$name','','$s_id', '$breakfast', '$lunch', '$dinner','$info','$address','$lat','$log', '$distance','$phone')";
	
	$sql2 = "INSERT INTO menu VALUES (NULL,'$s_id', '$mon', '$tue', '$wed','$thu','$fri','$sat','$sun')";



		if ($conn->query($sql) === TRUE) {

		 $postArray = array(
		  
		      "name" => $_POST['name'],
		       "breakfast"=>  $_POST['breakfast'],
			"lunch"=>  $_POST['lunch'],
			"dinner"=>$_POST['dinner'],
			
			"info"=>$_POST['info'],
			"address"=>$_POST['address'],
			"distance"=>$_POST['distance'],
			"phone"=> $_POST['phone'],
			
			"lat"=>$_POST['lat'],
			"log"=>$_POST['log'],
			"s_id" => $_POST['s_id'],
			
			"mon" => $_POST['mon'],
			"tue" => $_POST['tue'],
			"wed" => $_POST['wed'],
			"thu" => $_POST['thu'],
			"fri" => $_POST['fri'],
			"sat" => $_POST['sat'],
			"sun" => $_POST['sun']
			
		    );

		 echo json_encode( $postArray );
		} else {
		    echo "Error: " . $sql . "<br>" . $conn->error;
		}


}






	
	





$conn->close();

?>