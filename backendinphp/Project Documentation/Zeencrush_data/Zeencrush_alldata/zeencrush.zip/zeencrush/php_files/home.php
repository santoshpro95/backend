<?php
mysql_connect("localhost", "zeencrush", "santoshpro95") or die("Connection Failed");
mysql_select_db("zeencrush")or die("Connection Failed");


$my_fb_id=$_POST['my_fb_id'];
$no_rows=$_POST['no'];
$sql = "Select * from persons where fb_id not in (select sender_id from friends where recipient_id = '$my_fb_id' union select recipient_id from friends where     sender_id = '$my_fb_id') and fb_id != '$my_fb_id' and active = 'true' ORDER BY id desc  LIMIT 20";

        $result = mysql_query($sql);
/*check data should be more than one*/
      // echo $result;

			    if (mysql_num_rows($result) > 0) {

         while ( $row = mysql_fetch_array($result) ) {

 					 $postArray[] = array(
    							"id" =>  $row['ID'],
						      "name" =>  $row['name'],
						      "fb_id" =>  $row['fb_id'],
                  "lat" =>  $row['lat'],
                  "log" =>  $row['log'],
                  "gender" =>  $row['gender'],
                  "birthday" =>  $row['birthday'],
                       "time" =>  $row['time'],
                        "about" =>  $row['about'],
                         "profession" =>  $row['profession'],
                         "location"=> $row['location']
						    );

   					 }

   		$output = json_encode(array('data' => $postArray));
   					  echo $output;
			}
      else{
     
     
      }



?>



