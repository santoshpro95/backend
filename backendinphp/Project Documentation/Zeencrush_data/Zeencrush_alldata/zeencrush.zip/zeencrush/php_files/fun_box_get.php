      <?php
mysql_connect("localhost", "zeencrush", "santoshpro95") or die("Connection Failed");
mysql_select_db("zeencrush")or die("Connection Failed");

/*get data from database*/

$my_fb_id = $_POST['my_fb_id'];
$friend_fb_id = $_POST['friend_fb_id'];

  $sql = "SELECT * from fun_box order by id asc";

        $result = mysql_query($sql);
/*check data should be more than one*/
    
          if (mysql_num_rows($result) > 0) {
         while ($row = mysql_fetch_array($result)) {

           $postArray[] = array(
      "id" =>  $row['Id'],
                     "friend_fb_id" =>  $row['friend_fb_id'],
                  "chat" =>  $row['chat'],
                  "friend_fb_name" =>  $row['friend_fb_name']
                );

             }

      $output = json_encode(array('data' => $postArray));
              echo $output;
      }

?>
